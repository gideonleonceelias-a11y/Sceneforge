package com.example.data

import android.util.Log
import com.example.model.AccentColorKey
import com.example.model.BeatType
import com.example.model.CharacterInsight
import com.example.model.CharacterProfile
import com.example.model.DramaticScript
import com.example.model.LineType
import com.example.model.ScriptBeat
import com.example.model.ScriptLine
import com.example.model.ScriptStatus
import com.google.firebase.Firebase
import com.google.firebase.ai.GenerativeModel
import com.google.firebase.ai.ai
import com.google.firebase.ai.type.Schema
import com.google.firebase.ai.type.generationConfig
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.withTimeout
import org.json.JSONArray
import org.json.JSONObject

private const val TAG = "AiStudioRepository"
private const val PRIMARY_MODEL = "gemini-3.8-flash"
private const val FAST_FALLBACK_MODEL = "gemini-3.5-flash-lite"
private const val PRIMARY_TIMEOUT_MS = 45_000L
private const val FALLBACK_TIMEOUT_MS = 35_000L

class AiStudioRepository {

    private val characterSchema = Schema.obj(
        properties = mapOf(
            "name" to Schema.string(description = "Distinctive, grounded full name for the character"),
            "role" to Schema.string(description = "Dramatic role: Protagonist, Antagonist, Foil, Mentor, or Confidant"),
            "archetype" to Schema.string(description = "Sharp 2-4 word dramatic archetype"),
            "ageOrLook" to Schema.string(description = "Casting look, age range, wardrobe/visual cue for video"),
            "coreDesire" to Schema.string(description = "What this character desperately wants to achieve or protect"),
            "fatalFlaw" to Schema.string(description = "Internal blind spot or contradiction that sabotages them"),
            "backstory" to Schema.string(description = "Concise formative secret or past event driving present tension"),
            "voiceStyle" to Schema.string(description = "How they speak: cadence, subtext, verbal habits, rhythm"),
            "accentColorKey" to Schema.enumeration(
                values = listOf("AMBER", "CRIMSON", "COBALT", "EMERALD", "VIOLET"),
                description = "Visual badge color matching their temperament"
            )
        )
    )

    private val characterModel by lazy {
        Firebase.ai.generativeModel(
            modelName = PRIMARY_MODEL,
            generationConfig = generationConfig {
                responseMimeType = "application/json"
                responseSchema = characterSchema
                temperature = 0.8f
                maxOutputTokens = 1200
            }
        )
    }

    private val characterFallbackModel by lazy {
        Firebase.ai.generativeModel(
            modelName = FAST_FALLBACK_MODEL,
            generationConfig = generationConfig {
                responseMimeType = "application/json"
                responseSchema = characterSchema
                temperature = 0.8f
                maxOutputTokens = 1200
            }
        )
    }

    private val insightSchema = Schema.obj(
        properties = mapOf(
            "coreContradiction" to Schema.string(description = "The psychological tug-of-war inside this character"),
            "pressureTrigger" to Schema.string(description = "Specific external event that breaks their composure on camera"),
            "relationshipTension" to Schema.string(description = "How they collide with others in a short dramatic scene"),
            "subtextLines" to Schema.array(
                items = Schema.string(),
                description = "3 short, cinematic dialogue lines packed with unspoken subtext"
            )
        )
    )

    private val insightModel by lazy {
        Firebase.ai.generativeModel(
            modelName = PRIMARY_MODEL,
            generationConfig = generationConfig {
                responseMimeType = "application/json"
                responseSchema = insightSchema
                temperature = 0.8f
                maxOutputTokens = 1000
            }
        )
    }

    private val insightFallbackModel by lazy {
        Firebase.ai.generativeModel(
            modelName = FAST_FALLBACK_MODEL,
            generationConfig = generationConfig {
                responseMimeType = "application/json"
                responseSchema = insightSchema
                temperature = 0.8f
                maxOutputTokens = 1000
            }
        )
    }

    private val scriptSchema = Schema.obj(
        properties = mapOf(
            "title" to Schema.string(description = "Evocative short film title"),
            "logline" to Schema.string(description = "One-sentence high-stakes dramatic logline"),
            "setting" to Schema.string(description = "Screenplay slugline e.g. INT. LAST TRAIN CAR - 2:14 AM"),
            "directorNotes" to Schema.string(description = "Concise visual framing, lighting, and performance direction"),
            "beats" to Schema.array(
                items = Schema.obj(
                    properties = mapOf(
                        "beatTitle" to Schema.string(description = "Short dramatic beat title"),
                        "beatType" to Schema.enumeration(
                            values = listOf("HOOK", "ESCALATION", "TWIST", "CLIMAX", "RESOLUTION")
                        ),
                        "cameraCue" to Schema.string(description = "Brief shot framing cue e.g. Tight OTS"),
                        "summary" to Schema.string(description = "What shifts emotionally in this beat")
                    )
                ),
                description = "3 to 5 dramatic story beats for a short video"
            ),
            "lines" to Schema.array(
                items = Schema.obj(
                    properties = mapOf(
                        "lineType" to Schema.enumeration(
                            values = listOf("ACTION", "DIALOGUE", "TRANSITION")
                        ),
                        "speaker" to Schema.string(description = "UPPERCASE character name for DIALOGUE, empty otherwise"),
                        "parenthetical" to Schema.string(description = "Brief acting beat or delivery note"),
                        "text" to Schema.string(description = "Concise action description, spoken line, or transition"),
                        "emotionCue" to Schema.string(description = "1-2 word emotional tone")
                    ),
                    optionalProperties = listOf("parenthetical", "emotionCue")
                ),
                description = "8 to 14 punchy screenplay lines mixing visual action and subtext-rich dialogue"
            )
        )
    )

    private val scriptModel by lazy {
        Firebase.ai.generativeModel(
            modelName = PRIMARY_MODEL,
            generationConfig = generationConfig {
                responseMimeType = "application/json"
                responseSchema = scriptSchema
                temperature = 0.8f
                maxOutputTokens = 2048
            }
        )
    }

    private val scriptFallbackModel by lazy {
        Firebase.ai.generativeModel(
            modelName = FAST_FALLBACK_MODEL,
            generationConfig = generationConfig {
                responseMimeType = "application/json"
                responseSchema = scriptSchema
                temperature = 0.8f
                maxOutputTokens = 2048
            }
        )
    }

    private suspend fun streamJsonWithFallback(
        primary: GenerativeModel,
        fallback: GenerativeModel,
        prompt: String,
        onProgress: (Int) -> Unit
    ): String {
        suspend fun runStream(model: GenerativeModel, timeoutMs: Long): String {
            val buffer = StringBuilder()
            withTimeout(timeoutMs) {
                model.generateContentStream(prompt).collect { chunk ->
                    val chunkText = chunk.text.orEmpty()
                    if (chunkText.isNotEmpty()) {
                        buffer.append(chunkText)
                        onProgress(buffer.length)
                    }
                }
            }
            val result = buffer.toString()
            if (result.isBlank()) {
                throw IllegalStateException("Model returned an empty response.")
            }
            return result
        }

        return try {
            runStream(primary, PRIMARY_TIMEOUT_MS)
        } catch (e: TimeoutCancellationException) {
            Log.w(TAG, "Primary model $PRIMARY_MODEL timed out after ${PRIMARY_TIMEOUT_MS}ms; retrying with $FAST_FALLBACK_MODEL", e)
            onProgress(0)
            runStream(fallback, FALLBACK_TIMEOUT_MS)
        }
    }

    suspend fun generateCharacterProfile(
        concept: String,
        preferredRole: String,
        genre: String,
        onProgress: (Int) -> Unit = {}
    ): Result<CharacterProfile> {
        return try {
            val prompt = """
                You are an acclaimed dramatic screenwriter for short-form narrative cinema.
                Create a psychologically compelling character dossier for a short dramatic video.
                Genre: $genre
                Preferred Role: $preferredRole
                Concept: $concept
                Keep each field vivid, concrete, and concise.
            """.trimIndent()

            val jsonText = streamJsonWithFallback(
                primary = characterModel,
                fallback = characterFallbackModel,
                prompt = prompt,
                onProgress = onProgress
            )
            val json = JSONObject(jsonText)

            val profile = CharacterProfile(
                name = json.optString("name", "Untitled Character").take(80),
                role = json.optString("role", preferredRole).ifBlank { preferredRole }.take(40),
                archetype = json.optString("archetype", "").take(80),
                ageOrLook = json.optString("ageOrLook", "").take(120),
                coreDesire = json.optString("coreDesire", "").take(500),
                fatalFlaw = json.optString("fatalFlaw", "").take(500),
                backstory = json.optString("backstory", "").take(2000),
                voiceStyle = json.optString("voiceStyle", "").take(400),
                accentColorKey = AccentColorKey.fromRaw(json.optString("accentColorKey")).name
            )
            Result.success(profile)
        } catch (e: TimeoutCancellationException) {
            Log.e(TAG, "Character generation timed out", e)
            Result.failure(Exception("Character generation timed out. Please check your connection and try again."))
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.e(TAG, "Failed to generate character profile", e)
            Result.failure(e)
        }
    }

    suspend fun analyzeCharacterConflict(
        character: CharacterProfile,
        onProgress: (Int) -> Unit = {}
    ): Result<CharacterInsight> {
        return try {
            val prompt = """
                You are a dramatic acting coach. Analyze this character dossier for short dramatic scenes:
                Name: ${character.name} (${character.role}, ${character.archetype})
                Look: ${character.ageOrLook}
                Core Desire: ${character.coreDesire}
                Fatal Flaw: ${character.fatalFlaw}
                Backstory: ${character.backstory}
                Voice: ${character.voiceStyle}
                Provide their core contradiction, camera pressure trigger, scene friction, and 3 short subtext dialogue lines.
            """.trimIndent()

            val jsonText = streamJsonWithFallback(
                primary = insightModel,
                fallback = insightFallbackModel,
                prompt = prompt,
                onProgress = onProgress
            )
            val json = JSONObject(jsonText)
            val linesArr = json.optJSONArray("subtextLines") ?: JSONArray()
            val lines = (0 until linesArr.length()).mapNotNull { idx ->
                linesArr.optString(idx).takeIf { it.isNotBlank() }
            }

            Result.success(
                CharacterInsight(
                    coreContradiction = json.optString("coreContradiction", ""),
                    pressureTrigger = json.optString("pressureTrigger", ""),
                    relationshipTension = json.optString("relationshipTension", ""),
                    subtextLines = lines
                )
            )
        } catch (e: TimeoutCancellationException) {
            Log.e(TAG, "Character insight timed out", e)
            Result.failure(Exception("Conflict analysis timed out. Please try again."))
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.e(TAG, "Failed to analyze character conflict", e)
            Result.failure(e)
        }
    }

    suspend fun forgeDramaticScript(
        premise: String,
        genre: String,
        tone: String,
        targetDurationSec: Int,
        cast: List<CharacterProfile>,
        onProgress: (Int) -> Unit = {}
    ): Result<DramaticScript> {
        return try {
            val castContext = if (cast.isEmpty()) {
                "No pre-built cast selected — invent 2 contrasting characters."
            } else {
                cast.joinToString("\n") { c ->
                    "- ${c.name} (${c.role}): Desire='${c.coreDesire.ifBlank { "Control" }}', Flaw='${c.fatalFlaw.ifBlank { "Pride" }}', Voice='${c.voiceStyle.ifBlank { "Taut" }}'"
                }
            }

            val prompt = """
                Write a tight, shootable short dramatic video script (~$targetDurationSec seconds).
                GENRE: $genre | TONE: ${tone.ifBlank { "Taut, cinematic" }}
                PREMISE: $premise
                CAST:
                $castContext
                
                Keep it punchy and visual:
                - 3 to 5 dramatic beats (HOOK -> ESCALATION -> CLIMAX -> RESOLUTION) with brief camera cues.
                - 8 to 14 crisp screenplay lines mixing visual ACTION and subtext-rich DIALOGUE faithful to each character's voice.
            """.trimIndent()

            val jsonText = streamJsonWithFallback(
                primary = scriptModel,
                fallback = scriptFallbackModel,
                prompt = prompt,
                onProgress = onProgress
            )
            val parsed = parseScriptJson(
                jsonText = jsonText,
                genre = genre,
                tone = tone,
                targetDurationSec = targetDurationSec.toLong(),
                cast = cast,
                status = ScriptStatus.DRAFT.name
            )
            Result.success(parsed)
        } catch (e: TimeoutCancellationException) {
            Log.e(TAG, "Script forge timed out", e)
            Result.failure(Exception("Script generation timed out. Please check your connection and try again."))
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.e(TAG, "Failed to forge dramatic script", e)
            Result.failure(e)
        }
    }

    suspend fun rewriteScriptScene(
        script: DramaticScript,
        cast: List<CharacterProfile>,
        directive: String,
        onProgress: (Int) -> Unit = {}
    ): Result<DramaticScript> {
        return try {
            val currentLinesText = script.lines.take(20).joinToString("\n") { line ->
                when (line.resolvedType()) {
                    LineType.ACTION -> "[ACTION] ${line.text}"
                    LineType.TRANSITION -> "[TRANSITION] ${line.text}"
                    LineType.DIALOGUE -> {
                        val paren = if (line.parenthetical.isNotBlank()) " (${line.parenthetical})" else ""
                        "${line.speaker}$paren: ${line.text}"
                    }
                }
            }
            val castSection = if (cast.isEmpty()) {
                "Cast: ${script.characterNames.joinToString(", ").ifBlank { "Existing speakers" }}"
            } else {
                cast.joinToString("\n") { c ->
                    "- ${c.name} (${c.role}): Desire='${c.coreDesire}', Flaw='${c.fatalFlaw}', Voice='${c.voiceStyle}'"
                }
            }

            val prompt = """
                You are a Script Doctor revising a short dramatic video script (~${script.targetDurationSec}s).
                DIRECTIVE: $directive
                TITLE: ${script.title} | GENRE: ${script.genre} | SETTING: ${script.setting}
                $castSection
                CURRENT LINES:
                $currentLinesText
                
                Return a sharpened 3-5 beat sheet and 8-14 revised screenplay lines honoring the directive.
            """.trimIndent()

            val jsonText = streamJsonWithFallback(
                primary = scriptModel,
                fallback = scriptFallbackModel,
                prompt = prompt,
                onProgress = onProgress
            )
            val revised = parseScriptJson(
                jsonText = jsonText,
                genre = script.genre,
                tone = script.tone,
                targetDurationSec = script.targetDurationSec,
                cast = cast,
                status = ScriptStatus.REFINED.name
            ).copy(
                id = script.id,
                userId = script.userId,
                characterIds = script.characterIds,
                characterNames = script.characterNames,
                createdAt = script.createdAt
            )
            Result.success(revised)
        } catch (e: TimeoutCancellationException) {
            Log.e(TAG, "Script rewrite timed out", e)
            Result.failure(Exception("Scene rewrite timed out. Please try again."))
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.e(TAG, "Failed to rewrite script scene", e)
            Result.failure(e)
        }
    }

    private fun parseScriptJson(
        jsonText: String,
        genre: String,
        tone: String,
        targetDurationSec: Long,
        cast: List<CharacterProfile>,
        status: String
    ): DramaticScript {
        val json = JSONObject(jsonText)
        val beatsJson = json.optJSONArray("beats") ?: JSONArray()
        val beats = (0 until beatsJson.length()).mapNotNull { i ->
            val obj = beatsJson.optJSONObject(i) ?: return@mapNotNull null
            ScriptBeat(
                beatTitle = obj.optString("beatTitle", "Beat ${i + 1}").take(80),
                beatType = BeatType.fromRaw(obj.optString("beatType")).name,
                cameraCue = obj.optString("cameraCue", "").take(120),
                summary = obj.optString("summary", "").take(400)
            )
        }.take(20)

        val linesJson = json.optJSONArray("lines") ?: JSONArray()
        val lines = (0 until linesJson.length()).mapNotNull { i ->
            val obj = linesJson.optJSONObject(i) ?: return@mapNotNull null
            val type = LineType.fromRaw(obj.optString("lineType"))
            ScriptLine(
                lineType = type.name,
                speaker = if (type == LineType.DIALOGUE) obj.optString("speaker", "CHARACTER").uppercase().take(60) else "",
                parenthetical = if (type == LineType.DIALOGUE) obj.optString("parenthetical", "").take(80) else "",
                text = obj.optString("text", "").take(800),
                emotionCue = obj.optString("emotionCue", "").take(60)
            )
        }.take(100)

        return DramaticScript(
            title = json.optString("title", "Untitled Scene").ifBlank { "Untitled Scene" }.take(120),
            genre = genre.ifBlank { "Drama" }.take(40),
            logline = json.optString("logline", "").take(500),
            setting = json.optString("setting", "INT. UNKNOWN LOCATION - NIGHT").take(160),
            tone = tone.take(120),
            targetDurationSec = targetDurationSec.coerceIn(15L, 900L),
            characterIds = cast.map { it.id }.filter { it.isNotBlank() }.take(12),
            characterNames = cast.map { it.name }.filter { it.isNotBlank() }.take(12),
            beats = beats,
            lines = lines,
            directorNotes = json.optString("directorNotes", "").take(2000),
            status = status
        )
    }
}
