package com.example.data

import com.example.firebase.OperationType
import com.example.firebase.handleFirestoreError
import com.example.model.CharacterProfile
import com.example.model.DramaticScript
import com.google.firebase.Firebase
import com.google.firebase.Timestamp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreException
import com.google.firebase.firestore.snapshots
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await

class StudioRepository(
    private val db: FirebaseFirestore,
    private val auth: FirebaseAuth = Firebase.auth
) {
    private fun requireAuthorizedUid(expectedUserId: String): String {
        val uid = auth.currentUser?.uid
            ?: throw IllegalStateException("Please sign in with Google before accessing your studio.")
        check(uid == expectedUserId) { "Signed-in account changed; refusing cross-user operation." }
        return uid
    }

    fun observeCharacters(userId: String): Flow<List<CharacterProfile>> {
        val path = "users/$userId/characters"
        return db.collection("users").document(userId).collection("characters")
            .snapshots()
            .map { snapshot ->
                snapshot.toObjects(
                    CharacterProfile::class.java,
                    DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                ).sortedByDescending { it.updatedAt ?: it.createdAt ?: Timestamp(0, 0) }
            }
            .catch { error ->
                val firestoreError = generateSequence(error) { it.cause }
                    .filterIsInstance<FirebaseFirestoreException>()
                    .firstOrNull()
                if (firestoreError == null && error is CancellationException) throw error
                val toLog = firestoreError ?: (error as? Exception)
                if (toLog != null && auth.currentUser?.uid == userId) {
                    handleFirestoreError(toLog, OperationType.LIST, path)
                }
                throw error
            }
    }

    fun observeScripts(userId: String): Flow<List<DramaticScript>> {
        val path = "users/$userId/scripts"
        return db.collection("users").document(userId).collection("scripts")
            .snapshots()
            .map { snapshot ->
                snapshot.toObjects(
                    DramaticScript::class.java,
                    DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                ).sortedByDescending { it.updatedAt ?: it.createdAt ?: Timestamp(0, 0) }
            }
            .catch { error ->
                val firestoreError = generateSequence(error) { it.cause }
                    .filterIsInstance<FirebaseFirestoreException>()
                    .firstOrNull()
                if (firestoreError == null && error is CancellationException) throw error
                val toLog = firestoreError ?: (error as? Exception)
                if (toLog != null && auth.currentUser?.uid == userId) {
                    handleFirestoreError(toLog, OperationType.LIST, path)
                }
                throw error
            }
    }

    suspend fun saveCharacter(userId: String, character: CharacterProfile): Result<String> {
        val isCreate = character.id.isBlank()
        val docRef = if (isCreate) {
            db.collection("users").document(userId).collection("characters").document()
        } else {
            db.collection("users").document(userId).collection("characters").document(character.id)
        }
        return try {
            val uid = requireAuthorizedUid(userId)
            require(character.name.trim().isNotEmpty()) { "Character name cannot be empty." }
            require(character.name.trim().length <= 80) { "Character name must be 80 characters or fewer." }
            require(character.role.trim().isNotEmpty()) { "Character role cannot be empty." }

            if (isCreate) {
                docRef.set(character.toCreateMap(uid)).await()
            } else {
                docRef.update(character.toUpdateMap()).await()
            }
            Result.success(docRef.id)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, if (isCreate) OperationType.CREATE else OperationType.UPDATE, docRef.path)
            Result.failure(e)
        }
    }

    suspend fun deleteCharacter(userId: String, characterId: String): Result<Unit> {
        val docRef = db.collection("users").document(userId).collection("characters").document(characterId)
        return try {
            requireAuthorizedUid(userId)
            require(characterId.isNotBlank()) { "Character ID cannot be blank." }
            docRef.delete().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, docRef.path)
            Result.failure(e)
        }
    }

    suspend fun saveScript(userId: String, script: DramaticScript): Result<String> {
        val isCreate = script.id.isBlank()
        val docRef = if (isCreate) {
            db.collection("users").document(userId).collection("scripts").document()
        } else {
            db.collection("users").document(userId).collection("scripts").document(script.id)
        }
        return try {
            val uid = requireAuthorizedUid(userId)
            require(script.title.trim().isNotEmpty()) { "Script title cannot be empty." }
            require(script.title.trim().length <= 120) { "Script title must be 120 characters or fewer." }
            require(script.genre.trim().isNotEmpty()) { "Genre cannot be empty." }
            require(script.targetDurationSec in 15L..900L) { "Target duration must be between 15s and 15m." }

            if (isCreate) {
                docRef.set(script.toCreateMap(uid)).await()
            } else {
                docRef.update(script.toUpdateMap()).await()
            }
            Result.success(docRef.id)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, if (isCreate) OperationType.CREATE else OperationType.UPDATE, docRef.path)
            Result.failure(e)
        }
    }

    suspend fun deleteScript(userId: String, scriptId: String): Result<Unit> {
        val docRef = db.collection("users").document(userId).collection("scripts").document(scriptId)
        return try {
            requireAuthorizedUid(userId)
            require(scriptId.isNotBlank()) { "Script ID cannot be blank." }
            docRef.delete().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, docRef.path)
            Result.failure(e)
        }
    }
}
