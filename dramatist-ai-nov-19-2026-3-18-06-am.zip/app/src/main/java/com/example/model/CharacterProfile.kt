package com.example.model

import androidx.annotation.Keep
import androidx.compose.ui.graphics.Color
import com.example.ui.theme.BadgeAmber
import com.example.ui.theme.BadgeCobalt
import com.example.ui.theme.BadgeCrimson
import com.example.ui.theme.BadgeEmerald
import com.example.ui.theme.BadgeViolet
import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentId
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.IgnoreExtraProperties
import com.google.firebase.firestore.ServerTimestamp

enum class AccentColorKey(val label: String, val color: Color) {
    AMBER("Amber", BadgeAmber),
    CRIMSON("Crimson", BadgeCrimson),
    COBALT("Cobalt", BadgeCobalt),
    EMERALD("Emerald", BadgeEmerald),
    VIOLET("Violet", BadgeViolet);

    companion object {
        fun fromRaw(raw: String?): AccentColorKey =
            entries.firstOrNull { it.name == raw } ?: AMBER
    }
}

@Keep
@IgnoreExtraProperties
data class CharacterProfile(
    @DocumentId val id: String = "",
    val userId: String = "",
    val name: String = "",
    val role: String = "Protagonist",
    val archetype: String = "",
    val ageOrLook: String = "",
    val coreDesire: String = "",
    val fatalFlaw: String = "",
    val backstory: String = "",
    val voiceStyle: String = "",
    val accentColorKey: String = AccentColorKey.AMBER.name,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
) {
    fun resolvedColor(): AccentColorKey = AccentColorKey.fromRaw(accentColorKey)

    fun toCreateMap(ownerUid: String): Map<String, Any> = mapOf(
        "userId" to ownerUid,
        "name" to name.trim().take(80),
        "role" to role.trim().ifBlank { "Protagonist" }.take(40),
        "archetype" to archetype.trim().take(80),
        "ageOrLook" to ageOrLook.trim().take(120),
        "coreDesire" to coreDesire.trim().take(500),
        "fatalFlaw" to fatalFlaw.trim().take(500),
        "backstory" to backstory.trim().take(2000),
        "voiceStyle" to voiceStyle.trim().take(400),
        "accentColorKey" to AccentColorKey.fromRaw(accentColorKey).name,
        "createdAt" to FieldValue.serverTimestamp(),
        "updatedAt" to FieldValue.serverTimestamp()
    )

    fun toUpdateMap(): Map<String, Any> = mapOf(
        "name" to name.trim().take(80),
        "role" to role.trim().ifBlank { "Protagonist" }.take(40),
        "archetype" to archetype.trim().take(80),
        "ageOrLook" to ageOrLook.trim().take(120),
        "coreDesire" to coreDesire.trim().take(500),
        "fatalFlaw" to fatalFlaw.trim().take(500),
        "backstory" to backstory.trim().take(2000),
        "voiceStyle" to voiceStyle.trim().take(400),
        "accentColorKey" to AccentColorKey.fromRaw(accentColorKey).name,
        "updatedAt" to FieldValue.serverTimestamp()
    )
}

data class CharacterInsight(
    val coreContradiction: String,
    val pressureTrigger: String,
    val relationshipTension: String,
    val subtextLines: List<String>
)
