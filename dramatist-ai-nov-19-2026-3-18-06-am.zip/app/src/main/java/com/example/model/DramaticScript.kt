package com.example.model

import androidx.annotation.Keep
import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentId
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.IgnoreExtraProperties
import com.google.firebase.firestore.ServerTimestamp

enum class BeatType(val label: String) {
    HOOK("Hook"),
    ESCALATION("Escalation"),
    TWIST("Twist"),
    CLIMAX("Climax"),
    RESOLUTION("Resolution");

    companion object {
        fun fromRaw(raw: String?): BeatType =
            entries.firstOrNull { it.name == raw?.uppercase() } ?: ESCALATION
    }
}

enum class LineType(val label: String) {
    ACTION("Action"),
    DIALOGUE("Dialogue"),
    TRANSITION("Transition");

    companion object {
        fun fromRaw(raw: String?): LineType =
            entries.firstOrNull { it.name == raw?.uppercase() } ?: ACTION
    }
}

enum class ScriptStatus(val label: String) {
    DRAFT("Draft"),
    REFINED("Refined"),
    READY("Camera Ready");

    companion object {
        fun fromRaw(raw: String?): ScriptStatus =
            entries.firstOrNull { it.name == raw?.uppercase() } ?: DRAFT
    }
}

@Keep
@IgnoreExtraProperties
data class ScriptBeat(
    val beatTitle: String = "",
    val beatType: String = BeatType.HOOK.name,
    val cameraCue: String = "",
    val summary: String = ""
) {
    fun resolvedType(): BeatType = BeatType.fromRaw(beatType)

    fun toMap(): Map<String, Any> = mapOf(
        "beatTitle" to beatTitle.trim().take(80),
        "beatType" to BeatType.fromRaw(beatType).name,
        "cameraCue" to cameraCue.trim().take(120),
        "summary" to summary.trim().take(400)
    )
}

@Keep
@IgnoreExtraProperties
data class ScriptLine(
    val lineType: String = LineType.ACTION.name,
    val speaker: String = "",
    val parenthetical: String = "",
    val text: String = "",
    val emotionCue: String = ""
) {
    fun resolvedType(): LineType = LineType.fromRaw(lineType)

    fun toMap(): Map<String, Any> = mapOf(
        "lineType" to LineType.fromRaw(lineType).name,
        "speaker" to speaker.trim().take(60),
        "parenthetical" to parenthetical.trim().take(80),
        "text" to text.trim().take(800),
        "emotionCue" to emotionCue.trim().take(60)
    )
}

@Keep
@IgnoreExtraProperties
data class DramaticScript(
    @DocumentId val id: String = "",
    val userId: String = "",
    val title: String = "",
    val genre: String = "Thriller",
    val logline: String = "",
    val setting: String = "",
    val tone: String = "",
    val targetDurationSec: Long = 60L,
    val characterIds: List<String> = emptyList(),
    val characterNames: List<String> = emptyList(),
    val beats: List<ScriptBeat> = emptyList(),
    val lines: List<ScriptLine> = emptyList(),
    val directorNotes: String = "",
    val status: String = ScriptStatus.DRAFT.name,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
) {
    fun resolvedStatus(): ScriptStatus = ScriptStatus.fromRaw(status)

    fun formattedDuration(): String {
        val sec = targetDurationSec.coerceIn(15L, 900L)
        return if (sec < 60L) "${sec}s" else {
            val mins = sec / 60L
            val rem = sec % 60L
            if (rem == 0L) "${mins}m" else "${mins}m ${rem}s"
        }
    }

    fun toCreateMap(ownerUid: String): Map<String, Any> = mapOf(
        "userId" to ownerUid,
        "title" to title.trim().take(120),
        "genre" to genre.trim().ifBlank { "Drama" }.take(40),
        "logline" to logline.trim().take(500),
        "setting" to setting.trim().take(160),
        "tone" to tone.trim().take(120),
        "targetDurationSec" to targetDurationSec.coerceIn(15L, 900L),
        "characterIds" to characterIds.take(12),
        "characterNames" to characterNames.take(12),
        "beats" to beats.take(20).map { it.toMap() },
        "lines" to lines.take(100).map { it.toMap() },
        "directorNotes" to directorNotes.trim().take(2000),
        "status" to ScriptStatus.fromRaw(status).name,
        "createdAt" to FieldValue.serverTimestamp(),
        "updatedAt" to FieldValue.serverTimestamp()
    )

    fun toUpdateMap(): Map<String, Any> = mapOf(
        "title" to title.trim().take(120),
        "genre" to genre.trim().ifBlank { "Drama" }.take(40),
        "logline" to logline.trim().take(500),
        "setting" to setting.trim().take(160),
        "tone" to tone.trim().take(120),
        "targetDurationSec" to targetDurationSec.coerceIn(15L, 900L),
        "characterIds" to characterIds.take(12),
        "characterNames" to characterNames.take(12),
        "beats" to beats.take(20).map { it.toMap() },
        "lines" to lines.take(100).map { it.toMap() },
        "directorNotes" to directorNotes.trim().take(2000),
        "status" to ScriptStatus.fromRaw(status).name,
        "updatedAt" to FieldValue.serverTimestamp()
    )
}
