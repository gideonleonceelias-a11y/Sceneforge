package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.Save
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.R
import com.example.model.AccentColorKey
import com.example.model.CharacterInsight
import com.example.model.CharacterProfile
import com.example.ui.components.AiLoadingBanner
import com.example.ui.components.CHARACTER_ROLES
import com.example.ui.components.DRAMATIC_GENRES
import com.example.ui.components.ErrorBanner
import com.example.ui.viewmodel.AiState
import com.example.ui.viewmodel.StudioViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CharacterStudioScreen(
    existingCharacter: CharacterProfile?,
    viewModel: StudioViewModel,
    onBack: () -> Unit
) {
    val aiCharacterState by viewModel.aiCharacterState.collectAsStateWithLifecycle()
    val aiInsightState by viewModel.aiInsightState.collectAsStateWithLifecycle()
    val isSaving by viewModel.isSaving.collectAsStateWithLifecycle()

    var name by remember(existingCharacter?.id) { mutableStateOf(existingCharacter?.name.orEmpty()) }
    var role by remember(existingCharacter?.id) { mutableStateOf(existingCharacter?.role?.ifBlank { "Protagonist" } ?: "Protagonist") }
    var archetype by remember(existingCharacter?.id) { mutableStateOf(existingCharacter?.archetype.orEmpty()) }
    var ageOrLook by remember(existingCharacter?.id) { mutableStateOf(existingCharacter?.ageOrLook.orEmpty()) }
    var coreDesire by remember(existingCharacter?.id) { mutableStateOf(existingCharacter?.coreDesire.orEmpty()) }
    var fatalFlaw by remember(existingCharacter?.id) { mutableStateOf(existingCharacter?.fatalFlaw.orEmpty()) }
    var backstory by remember(existingCharacter?.id) { mutableStateOf(existingCharacter?.backstory.orEmpty()) }
    var voiceStyle by remember(existingCharacter?.id) { mutableStateOf(existingCharacter?.voiceStyle.orEmpty()) }
    var accentColorKey by remember(existingCharacter?.id) {
        mutableStateOf(existingCharacter?.resolvedColor() ?: AccentColorKey.AMBER)
    }

    var architectExpanded by remember { mutableStateOf(existingCharacter == null) }
    var conceptPrompt by remember { mutableStateOf("") }
    var conceptGenre by remember { mutableStateOf("Thriller") }

    DisposableEffect(Unit) {
        onDispose {
            viewModel.resetAiCharacterState()
            viewModel.resetAiInsightState()
        }
    }

    LaunchedEffect(aiCharacterState) {
        val state = aiCharacterState
        if (state is AiState.Success) {
            val generated = state.data
            name = generated.name
            role = generated.role
            archetype = generated.archetype
            ageOrLook = generated.ageOrLook
            coreDesire = generated.coreDesire
            fatalFlaw = generated.fatalFlaw
            backstory = generated.backstory
            voiceStyle = generated.voiceStyle
            accentColorKey = generated.resolvedColor()
            architectExpanded = false
            viewModel.resetAiCharacterState()
        }
    }

    val currentDraft = CharacterProfile(
        id = existingCharacter?.id.orEmpty(),
        userId = existingCharacter?.userId.orEmpty(),
        name = name,
        role = role,
        archetype = archetype,
        ageOrLook = ageOrLook,
        coreDesire = coreDesire,
        fatalFlaw = fatalFlaw,
        backstory = backstory,
        voiceStyle = voiceStyle,
        accentColorKey = accentColorKey.name,
        createdAt = existingCharacter?.createdAt,
        updatedAt = existingCharacter?.updatedAt
    )

    Scaffold(
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = if (existingCharacter == null) "New Character" else "Character Dossier",
                        style = MaterialTheme.typography.headlineMedium
                    )
                },
                navigationIcon = {
                    IconButton(
                        onClick = onBack,
                        modifier = Modifier.testTag("character_back_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = stringResource(R.string.cd_navigate_back)
                        )
                    }
                },
                actions = {
                    Button(
                        onClick = {
                            viewModel.saveCharacter(currentDraft) { onBack() }
                        },
                        enabled = !isSaving && name.isNotBlank(),
                        modifier = Modifier
                            .padding(end = 12.dp)
                            .testTag("save_character_button")
                    ) {
                        if (isSaving) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(16.dp),
                                color = MaterialTheme.colorScheme.onPrimary,
                                strokeWidth = 2.dp
                            )
                        } else {
                            Icon(Icons.Filled.Save, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Save")
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background
                )
            )
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .navigationBarsPadding(),
            contentAlignment = Alignment.TopCenter
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .widthIn(max = 720.dp)
                    .verticalScroll(rememberScrollState())
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // AI Character Architect Card
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.55f)),
                    shape = RoundedCornerShape(18.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { architectExpanded = !architectExpanded }
                                .testTag("toggle_ai_architect"),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Filled.AutoAwesome,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary
                                )
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text(
                                        text = "AI Character Architect",
                                        style = MaterialTheme.typography.titleMedium,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                    Text(
                                        text = "Generate a complete psychological dossier from a seed idea",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                            Icon(
                                imageVector = if (architectExpanded) Icons.Filled.ExpandLess else Icons.Filled.ExpandMore,
                                contentDescription = null
                            )
                        }

                        AnimatedVisibility(visible = architectExpanded) {
                            Column(
                                modifier = Modifier.padding(top = 14.dp),
                                verticalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                if (aiCharacterState is AiState.Loading) {
                                    AiLoadingBanner(
                                        title = "Sculpting character...",
                                        subtitle = (aiCharacterState as AiState.Loading).progressDetail
                                            ?: "Crafting desire, fatal flaw, backstory, and vocal cadence."
                                    )
                                }
                                if (aiCharacterState is AiState.Error) {
                                    ErrorBanner(
                                        message = (aiCharacterState as AiState.Error).message,
                                        onDismiss = { viewModel.resetAiCharacterState() }
                                    )
                                }

                                OutlinedTextField(
                                    value = conceptPrompt,
                                    onValueChange = { conceptPrompt = it },
                                    label = { Text("Seed Concept") },
                                    placeholder = { Text("e.g. Burnt-out forensic accountant hiding a witness") },
                                    minLines = 2,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .testTag("character_concept_input")
                                )

                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .horizontalScroll(rememberScrollState()),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    DRAMATIC_GENRES.forEach { genre ->
                                        FilterChip(
                                            selected = conceptGenre == genre,
                                            onClick = { conceptGenre = genre },
                                            label = { Text(genre) }
                                        )
                                    }
                                }

                                Button(
                                    onClick = {
                                        viewModel.generateCharacterDraft(conceptPrompt, role, conceptGenre)
                                    },
                                    enabled = aiCharacterState !is AiState.Loading && conceptPrompt.isNotBlank(),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(48.dp)
                                        .testTag("generate_character_button"),
                                    shape = RoundedCornerShape(12.dp)
                                ) {
                                    Icon(Icons.Filled.AutoAwesome, contentDescription = null, modifier = Modifier.size(18.dp))
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("Generate Dossier with AI", fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }

                // Core Identity
                OutlinedTextField(
                    value = name,
                    onValueChange = { if (it.length <= 80) name = it },
                    label = { Text("Character Name *") },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("character_name_input")
                )

                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "Narrative Role",
                        style = MaterialTheme.typography.titleSmall,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        CHARACTER_ROLES.forEach { item ->
                            FilterChip(
                                selected = role == item,
                                onClick = { role = item },
                                label = { Text(item) },
                                modifier = Modifier.testTag("role_chip_${item.lowercase()}")
                            )
                        }
                    }
                }

                // Badge Color Selector
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "Cast Accent Color",
                        style = MaterialTheme.typography.titleSmall,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        AccentColorKey.entries.forEach { key ->
                            val selected = accentColorKey == key
                            Box(
                                modifier = Modifier
                                    .size(48.dp)
                                    .clip(CircleShape)
                                    .background(key.color.copy(alpha = 0.22f))
                                    .border(
                                        width = if (selected) 2.5.dp else 1.dp,
                                        color = if (selected) key.color else MaterialTheme.colorScheme.outline,
                                        shape = CircleShape
                                    )
                                    .clickable { accentColorKey = key }
                                    .testTag("accent_color_${key.name.lowercase()}"),
                                contentAlignment = Alignment.Center
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(22.dp)
                                        .clip(CircleShape)
                                        .background(key.color),
                                    contentAlignment = Alignment.Center
                                ) {
                                    if (selected) {
                                        Icon(
                                            imageVector = Icons.Filled.Check,
                                            contentDescription = key.label,
                                            tint = MaterialTheme.colorScheme.background,
                                            modifier = Modifier.size(14.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                OutlinedTextField(
                    value = archetype,
                    onValueChange = { if (it.length <= 80) archetype = it },
                    label = { Text("Dramatic Archetype") },
                    placeholder = { Text("e.g. Reluctant Whistleblower") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = ageOrLook,
                    onValueChange = { if (it.length <= 120) ageOrLook = it },
                    label = { Text("Casting Look & Visual Cues") },
                    placeholder = { Text("e.g. Late 30s, wool coat, restless hands") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = coreDesire,
                    onValueChange = { if (it.length <= 500) coreDesire = it },
                    label = { Text("Core Desire (What they want desperately)") },
                    minLines = 2,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("character_desire_input")
                )

                OutlinedTextField(
                    value = fatalFlaw,
                    onValueChange = { if (it.length <= 500) fatalFlaw = it },
                    label = { Text("Fatal Flaw (What sabotages them)") },
                    minLines = 2,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("character_flaw_input")
                )

                OutlinedTextField(
                    value = voiceStyle,
                    onValueChange = { if (it.length <= 400) voiceStyle = it },
                    label = { Text("Voice & Dialogue Rhythm") },
                    placeholder = { Text("e.g. Short clipped sentences, deflects with wry questions") },
                    minLines = 2,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("character_voice_input")
                )

                OutlinedTextField(
                    value = backstory,
                    onValueChange = { if (it.length <= 2000) backstory = it },
                    label = { Text("Secret / Formative Backstory") },
                    minLines = 3,
                    modifier = Modifier.fillMaxWidth()
                )

                // Subtext & Conflict Coach
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                    shape = RoundedCornerShape(18.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Filled.Psychology,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.secondary
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Subtext & Conflict Coach",
                                style = MaterialTheme.typography.titleMedium
                            )
                        }
                        Text(
                            text = "Ask AI to stress-test this character's psychology and write 3 subtext-rich sample lines.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )

                        OutlinedButton(
                            onClick = { viewModel.analyzeCharacterConflict(currentDraft) },
                            enabled = aiInsightState !is AiState.Loading && name.isNotBlank(),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp)
                                .testTag("analyze_conflict_button"),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Icon(Icons.Filled.AutoAwesome, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Analyze Subtext & Conflict")
                        }

                        when (val insight = aiInsightState) {
                            is AiState.Loading -> {
                                AiLoadingBanner(
                                    title = "Stress-testing character arc...",
                                    subtitle = insight.progressDetail
                                        ?: "Finding internal contradictions and scene-ready subtext."
                                )
                            }
                            is AiState.Error -> {
                                ErrorBanner(
                                    message = insight.message,
                                    onDismiss = { viewModel.resetAiInsightState() }
                                )
                            }
                            is AiState.Success -> {
                                CharacterInsightPanel(insight.data)
                            }
                            AiState.Idle -> Unit
                        }
                    }
                }

                Spacer(modifier = Modifier.height(24.dp))
            }
        }
    }
}

@Composable
private fun CharacterInsightPanel(insight: CharacterInsight) {
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        InsightField(title = "CORE CONTRADICTION", value = insight.coreContradiction)
        InsightField(title = "CAMERA PRESSURE TRIGGER", value = insight.pressureTrigger)
        InsightField(title = "SCENE FRICTION", value = insight.relationshipTension)
        if (insight.subtextLines.isNotEmpty()) {
            Text(
                text = "SAMPLE SUBTEXT LINES",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.primary
            )
            insight.subtextLines.forEach { line ->
                Surface(
                    color = MaterialTheme.colorScheme.surfaceVariant,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "\"$line\"",
                        style = MaterialTheme.typography.labelMedium,
                        fontStyle = FontStyle.Italic,
                        color = MaterialTheme.colorScheme.onSurface,
                        modifier = Modifier.padding(12.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun InsightField(title: String, value: String) {
    if (value.isBlank()) return
    Surface(
        color = MaterialTheme.colorScheme.surfaceVariant,
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Text(
                text = title,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.primary
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = value,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurface
            )
        }
    }
}
