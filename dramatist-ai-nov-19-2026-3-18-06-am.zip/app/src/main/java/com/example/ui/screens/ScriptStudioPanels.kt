package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowLeft
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.RestartAlt
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.example.model.BeatType
import com.example.model.DramaticScript
import com.example.model.LineType
import com.example.model.ScriptBeat
import com.example.model.ScriptLine
import com.example.ui.components.AiLoadingBanner
import com.example.ui.components.DRAMATIC_GENRES
import com.example.ui.components.ErrorBanner
import com.example.ui.components.StatusPill
import com.example.ui.viewmodel.AiState
import kotlinx.coroutines.delay

private val SCENE_DOCTOR_PRESETS = listOf(
    "Sharpen subtext so characters never say what they truly feel directly.",
    "Escalate emotional stakes and add sharper power shifts between lines.",
    "Inject a late-scene dramatic twist that reframes the opening line.",
    "Tighten pacing for a punchy 60-second vertical video cut.",
    "Replace exposition with visual action and camera behavior."
)

@Composable
fun ScriptBeatsAndNotesPanel(
    title: String,
    onTitleChange: (String) -> Unit,
    genre: String,
    onGenreChange: (String) -> Unit,
    setting: String,
    onSettingChange: (String) -> Unit,
    logline: String,
    onLoglineChange: (String) -> Unit,
    tone: String,
    onToneChange: (String) -> Unit,
    directorNotes: String,
    onDirectorNotesChange: (String) -> Unit,
    beats: List<ScriptBeat>,
    onAddBeat: (ScriptBeat) -> Unit,
    onDeleteBeat: (Int) -> Unit
) {
    var showBeatDialog by remember { mutableStateOf(false) }

    if (showBeatDialog) {
        AddBeatDialog(
            onConfirm = { beat ->
                onAddBeat(beat)
                showBeatDialog = false
            },
            onDismiss = { showBeatDialog = false }
        )
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        OutlinedTextField(
            value = title,
            onValueChange = { if (it.length <= 120) onTitleChange(it) },
            label = { Text("Script Title *") },
            singleLine = true,
            modifier = Modifier
                .fillMaxWidth()
                .testTag("script_title_input")
        )

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            DRAMATIC_GENRES.forEach { item ->
                FilterChip(
                    selected = genre == item,
                    onClick = { onGenreChange(item) },
                    label = { Text(item) }
                )
            }
        }

        OutlinedTextField(
            value = setting,
            onValueChange = { if (it.length <= 160) onSettingChange(it) },
            label = { Text("Scene Slugline") },
            placeholder = { Text("INT. SUBWAY CAR - 2:14 AM") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )

        OutlinedTextField(
            value = logline,
            onValueChange = { if (it.length <= 500) onLoglineChange(it) },
            label = { Text("Dramatic Logline") },
            minLines = 2,
            modifier = Modifier.fillMaxWidth()
        )

        OutlinedTextField(
            value = tone,
            onValueChange = { if (it.length <= 120) onToneChange(it) },
            label = { Text("Tone & Pacing") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )

        OutlinedTextField(
            value = directorNotes,
            onValueChange = { if (it.length <= 2000) onDirectorNotesChange(it) },
            label = { Text("Director's Camera & Lighting Notes") },
            minLines = 3,
            modifier = Modifier.fillMaxWidth()
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "Dramatic Beat Sheet (${beats.size})",
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.primary
            )
            OutlinedButton(
                onClick = { showBeatDialog = true },
                modifier = Modifier.testTag("add_beat_button")
            ) {
                Icon(Icons.Filled.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("Add Beat")
            }
        }

        if (beats.isEmpty()) {
            Surface(
                color = MaterialTheme.colorScheme.surfaceVariant,
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = "No story beats added yet. Add structural beats or run Scene Doctor.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(14.dp)
                )
            }
        } else {
            beats.forEachIndexed { index, beat ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                StatusPill(
                                    label = "${index + 1}. ${beat.resolvedType().label}",
                                    containerColor = MaterialTheme.colorScheme.primaryContainer,
                                    contentColor = MaterialTheme.colorScheme.onPrimaryContainer
                                )
                                Text(
                                    text = beat.beatTitle,
                                    style = MaterialTheme.typography.titleSmall
                                )
                            }
                            TextButton(onClick = { onDeleteBeat(index) }) {
                                Text("Remove")
                            }
                        }
                        if (beat.cameraCue.isNotBlank()) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Filled.Videocam,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(14.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = beat.cameraCue,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }
                        }
                        if (beat.summary.isNotBlank()) {
                            Text(
                                text = beat.summary,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
        }
        Spacer(modifier = Modifier.height(24.dp))
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SceneDoctorPanel(
    aiRewriteState: AiState<DramaticScript>,
    onRequestRewrite: (String) -> Unit,
    onApplyRewrite: (DramaticScript) -> Unit,
    onDismissRewrite: () -> Unit
) {
    var directive by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.5f)),
            shape = RoundedCornerShape(18.dp)
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Filled.AutoAwesome,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "AI Scene Doctor",
                        style = MaterialTheme.typography.titleMedium
                    )
                }
                Text(
                    text = "Pick a dramatic rewrite pass or give your own director's note. Gemini will sharpen beats and dialogue while keeping your cast voices intact.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        Text(
            text = "Quick Rewrite Passes",
            style = MaterialTheme.typography.titleSmall,
            color = MaterialTheme.colorScheme.primary
        )

        FlowRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            SCENE_DOCTOR_PRESETS.forEachIndexed { idx, preset ->
                Surface(
                    color = if (directive == preset) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surface,
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(
                        1.dp,
                        if (directive == preset) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline
                    ),
                    modifier = Modifier
                        .clickable { directive = preset }
                        .testTag("doctor_preset_$idx")
                ) {
                    Text(
                        text = preset,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurface,
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp)
                    )
                }
            }
        }

        OutlinedTextField(
            value = directive,
            onValueChange = { directive = it },
            label = { Text("Director's Rewrite Note") },
            minLines = 2,
            modifier = Modifier
                .fillMaxWidth()
                .testTag("doctor_directive_input")
        )

        Button(
            onClick = { onRequestRewrite(directive) },
            enabled = aiRewriteState !is AiState.Loading && directive.isNotBlank(),
            shape = RoundedCornerShape(14.dp),
            modifier = Modifier
                .fillMaxWidth()
                .height(50.dp)
                .testTag("doctor_rewrite_button")
        ) {
            Icon(Icons.Filled.AutoAwesome, contentDescription = null, modifier = Modifier.size(18.dp))
            Spacer(modifier = Modifier.width(8.dp))
            Text("Run Scene Doctor", fontWeight = FontWeight.Bold)
        }

        when (aiRewriteState) {
            is AiState.Loading -> {
                AiLoadingBanner(
                    title = "Rewriting scene...",
                    subtitle = aiRewriteState.progressDetail
                        ?: "Elevating tension, subtext, and camera beats."
                )
            }
            is AiState.Error -> {
                ErrorBanner(
                    message = aiRewriteState.message,
                    onDismiss = onDismissRewrite
                )
            }
            is AiState.Success -> {
                val revised = aiRewriteState.data
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary),
                    shape = RoundedCornerShape(18.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text(
                            text = "Proposed Revision Ready",
                            style = MaterialTheme.typography.titleMedium,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Text(
                            text = "${revised.title} · ${revised.beats.size} beats · ${revised.lines.size} lines",
                            style = MaterialTheme.typography.labelMedium
                        )
                        if (revised.logline.isNotBlank()) {
                            Text(
                                text = revised.logline,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        revised.lines.take(4).forEach { previewLine ->
                            val prefix = if (previewLine.resolvedType() == LineType.DIALOGUE) {
                                "${previewLine.speaker}: "
                            } else ""
                            Text(
                                text = "$prefix${previewLine.text}",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            OutlinedButton(
                                onClick = onDismissRewrite,
                                modifier = Modifier.weight(1f)
                            ) {
                                Text("Discard")
                            }
                            Button(
                                onClick = { onApplyRewrite(revised) },
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("apply_rewrite_button")
                            ) {
                                Text("Apply & Save")
                            }
                        }
                    }
                }
            }
            AiState.Idle -> Unit
        }
    }
}

@Composable
fun TableReadPanel(
    setting: String,
    lines: List<ScriptLine>
) {
    if (lines.isEmpty()) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = "Add script lines first to rehearse in Table Read mode.",
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center
            )
        }
        return
    }

    var currentIndex by remember(lines.size) { mutableIntStateOf(0) }
    var autoPlay by remember { mutableStateOf(false) }
    var paceMs by remember { mutableLongStateOf(3200L) }

    val safeIndex = currentIndex.coerceIn(0, lines.lastIndex)
    val activeLine = lines[safeIndex]

    LaunchedEffect(autoPlay, safeIndex, paceMs) {
        if (autoPlay) {
            delay(paceMs)
            if (safeIndex < lines.lastIndex) {
                currentIndex = safeIndex + 1
            } else {
                autoPlay = false
            }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = setting.ifBlank { "REHEARSAL STAGE" }.uppercase(),
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.primary
                )
                Text(
                    text = "Cue ${safeIndex + 1} / ${lines.size}",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            LinearProgressIndicator(
                progress = { (safeIndex + 1).toFloat() / lines.size.toFloat() },
                modifier = Modifier.fillMaxWidth(),
                color = MaterialTheme.colorScheme.primary
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(4500L to "Slow", 3200L to "Natural", 2000L to "Brisk").forEach { (ms, label) ->
                    FilterChip(
                        selected = paceMs == ms,
                        onClick = { paceMs = ms },
                        label = { Text(label) }
                    )
                }
            }
        }

        Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.55f)),
            shape = RoundedCornerShape(24.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                val type = activeLine.resolvedType()
                if (type == LineType.DIALOGUE) {
                    StatusPill(
                        label = activeLine.speaker.ifBlank { "SPEAKER" },
                        containerColor = MaterialTheme.colorScheme.primaryContainer,
                        contentColor = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                } else {
                    StatusPill(
                        label = type.label,
                        containerColor = MaterialTheme.colorScheme.surfaceVariant,
                        contentColor = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                if (activeLine.parenthetical.isNotBlank()) {
                    Text(
                        text = "(${activeLine.parenthetical})",
                        style = MaterialTheme.typography.bodyMedium,
                        fontStyle = FontStyle.Italic,
                        color = MaterialTheme.colorScheme.primary,
                        textAlign = TextAlign.Center
                    )
                }

                Text(
                    text = activeLine.text,
                    style = if (type == LineType.DIALOGUE) MaterialTheme.typography.headlineMedium else MaterialTheme.typography.titleLarge,
                    color = MaterialTheme.colorScheme.onSurface,
                    textAlign = TextAlign.Center
                )

                if (activeLine.emotionCue.isNotBlank()) {
                    StatusPill(
                        label = "TONE: ${activeLine.emotionCue}",
                        containerColor = MaterialTheme.colorScheme.secondaryContainer,
                        contentColor = MaterialTheme.colorScheme.onSecondaryContainer
                    )
                }
            }
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedButton(
                onClick = {
                    autoPlay = false
                    currentIndex = 0
                },
                modifier = Modifier.height(50.dp)
            ) {
                Icon(Icons.Filled.RestartAlt, contentDescription = "Restart")
            }
            OutlinedButton(
                onClick = {
                    autoPlay = false
                    if (safeIndex > 0) currentIndex = safeIndex - 1
                },
                enabled = safeIndex > 0,
                modifier = Modifier
                    .weight(1f)
                    .height(50.dp)
            ) {
                Icon(Icons.AutoMirrored.Filled.KeyboardArrowLeft, contentDescription = null)
                Text("Prev")
            }
            Button(
                onClick = { autoPlay = !autoPlay },
                modifier = Modifier
                    .weight(1.2f)
                    .height(50.dp)
                    .testTag("table_read_play_button")
            ) {
                Icon(
                    imageVector = if (autoPlay) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                    contentDescription = null
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(if (autoPlay) "Pause" else "Auto")
            }
            OutlinedButton(
                onClick = {
                    autoPlay = false
                    if (safeIndex < lines.lastIndex) currentIndex = safeIndex + 1
                },
                enabled = safeIndex < lines.lastIndex,
                modifier = Modifier
                    .weight(1f)
                    .height(50.dp)
            ) {
                Text("Next")
                Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, contentDescription = null)
            }
        }
    }
}

@Composable
private fun AddBeatDialog(
    onConfirm: (ScriptBeat) -> Unit,
    onDismiss: () -> Unit
) {
    var beatTitle by remember { mutableStateOf("") }
    var beatType by remember { mutableStateOf(BeatType.ESCALATION) }
    var cameraCue by remember { mutableStateOf("") }
    var summary by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = MaterialTheme.colorScheme.surface,
        title = { Text("Add Story Beat") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(
                    modifier = Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    BeatType.entries.forEach { type ->
                        FilterChip(
                            selected = beatType == type,
                            onClick = { beatType = type },
                            label = { Text(type.label) }
                        )
                    }
                }
                OutlinedTextField(
                    value = beatTitle,
                    onValueChange = { if (it.length <= 80) beatTitle = it },
                    label = { Text("Beat Title *") },
                    singleLine = true
                )
                OutlinedTextField(
                    value = cameraCue,
                    onValueChange = { if (it.length <= 120) cameraCue = it },
                    label = { Text("Camera Cue") },
                    singleLine = true
                )
                OutlinedTextField(
                    value = summary,
                    onValueChange = { if (it.length <= 400) summary = it },
                    label = { Text("What shifts in this beat?") },
                    minLines = 2
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    onConfirm(
                        ScriptBeat(
                            beatTitle = beatTitle.trim(),
                            beatType = beatType.name,
                            cameraCue = cameraCue.trim(),
                            summary = summary.trim()
                        )
                    )
                },
                enabled = beatTitle.isNotBlank()
            ) {
                Text("Add")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}
