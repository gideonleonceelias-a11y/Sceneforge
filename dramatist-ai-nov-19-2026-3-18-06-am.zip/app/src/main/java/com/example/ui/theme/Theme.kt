package com.example.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.unit.dp

private val SceneForgeDarkColorScheme = darkColorScheme(
    primary = SpotlightAmber,
    onPrimary = ObsidianBg,
    primaryContainer = SpotlightAmberDark,
    onPrimaryContainer = SpotlightAmberSoft,
    secondary = CrimsonCue,
    onSecondary = IvoryInk,
    secondaryContainer = CrimsonCueContainer,
    onSecondaryContainer = CrimsonCueSoft,
    tertiary = BadgeCobalt,
    onTertiary = ObsidianBg,
    background = ObsidianBg,
    onBackground = IvoryInk,
    surface = SlateSurface,
    onSurface = IvoryInk,
    surfaceVariant = SlateSurfaceVariant,
    onSurfaceVariant = MutedAsh,
    surfaceContainerLowest = ObsidianBg,
    surfaceContainerLow = SlateSurface,
    surfaceContainer = SlateSurfaceVariant,
    surfaceContainerHigh = SlateSurfaceHigh,
    outline = HairlineSlate,
    outlineVariant = SlateSurfaceHigh,
    error = CrimsonCue,
    onError = IvoryInk
)

private val SceneForgeLightColorScheme = lightColorScheme(
    primary = BronzePrimary,
    onPrimary = PaperCream,
    primaryContainer = BronzeContainer,
    onPrimaryContainer = BronzeOnContainer,
    secondary = DeepCrimson,
    onSecondary = PaperCream,
    secondaryContainer = DeepCrimsonContainer,
    onSecondaryContainer = DeepCrimsonOnContainer,
    tertiary = BadgeCobalt,
    onTertiary = PaperCream,
    background = PaperCream,
    onBackground = StageInk,
    surface = PaperCard,
    onSurface = StageInk,
    surfaceVariant = PaperSurfaceHigh,
    onSurfaceVariant = PaperMutedInk,
    surfaceContainerLowest = PaperCream,
    surfaceContainerLow = PaperCard,
    surfaceContainer = PaperSurfaceHigh,
    surfaceContainerHigh = HairlinePaper,
    outline = HairlinePaper,
    outlineVariant = PaperSurfaceHigh,
    error = DeepCrimson,
    onError = PaperCream
)

val SceneForgeShapes = Shapes(
    small = RoundedCornerShape(8.dp),
    medium = RoundedCornerShape(14.dp),
    large = RoundedCornerShape(20.dp),
    extraLarge = RoundedCornerShape(28.dp)
)

@Composable
fun SceneForgeTheme(
    darkTheme: Boolean = true,
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) SceneForgeDarkColorScheme else SceneForgeLightColorScheme
    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        shapes = SceneForgeShapes,
        content = content
    )
}
