package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.PersonAdd
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.model.CharacterProfile
import com.example.ui.components.AiLoadingBanner
import com.example.ui.components.DRAMATIC_GENRES
import com.example.ui.components.ErrorBanner
import com.example.ui.viewmodel.AiState

private val DURATION_OPTIONS = listOf(
    30 to "30s Reel",
    60 to "60s Short",
    90 to "90s Scene",
    180 to "3m Film"
)

private val TONE_PRESETS = listOf(
    "Taut & Claustrophobic",
    "Quiet Heartbreak",
    "Sharp & Confrontational",
    "Moody Neo-Noir"
)

private val PREMISE_SPARKS = listOf(
    "Two estranged siblings meet in a hospital waiting room with an unsigned will.",
    "A whistleblower realizes her getaway driver works for the company she exposed.",
    "During a power outage in an elevator, a confession changes everything.",
    "An actor discovers the audition script is word-for-word from their real secret."
)

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun AiForgeTab(
    characters: List<CharacterProfile>,
    forgeState: AiState<String>,
    onForgeScript: (
        premise: String,
        genre: String,
        tone: String,
        targetDurationSec: Int,
        cast: List<CharacterProfile>
    ) -> Unit,
    onDismissForgeError: () -> Unit,
    onCreateCharacter: () -> Unit
) {
    var selectedCharacterIds by remember { mutableStateOf(setOf<String>()) }
    var selectedGenre by remember { mutableStateOf("Thriller") }
    var selectedDuration by remember { mutableIntStateOf(60) }
    var selectedTone by remember { mutableStateOf(TONE_PRESETS.first()) }
    var premise by remember { mutableStateOf("") }

    val isLoading = forgeState is AiState.Loading

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 96.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
            shape = RoundedCornerShape(20.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "Director's Script Forge",
                    style = MaterialTheme.typography.headlineMedium,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Cast your characters, set the runtime and emotional pressure, and Gemini will craft a beat-driven dramatic script.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        if (forgeState is AiState.Loading) {
            AiLoadingBanner(
                title = "Forging dramatic script...",
                subtitle = forgeState.progressDetail
                    ?: "Sculpting story beats, camera cues, and subtext dialogue."
            )
        }

        if (forgeState is AiState.Error) {
            ErrorBanner(
                message = forgeState.message,
                onDismiss = onDismissForgeError
            )
        }

        // Cast selector
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "1. Select Cast (Optional, up to 4)",
                    style = MaterialTheme.typography.titleSmall,
                    color = MaterialTheme.colorScheme.primary
                )
                if (characters.isEmpty()) {
                    OutlinedButton(
                        onClick = onCreateCharacter,
                        modifier = Modifier.testTag("forge_add_character_button")
                    ) {
                        Icon(Icons.Filled.PersonAdd, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("New Character")
                    }
                }
            }

            if (characters.isEmpty()) {
                Surface(
                    color = MaterialTheme.colorScheme.surfaceVariant,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "No cast profiles yet — AI can invent characters for this scene, or you can build custom characters first.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(12.dp)
                    )
                }
            } else {
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    characters.forEach { character ->
                        val isSelected = character.id in selectedCharacterIds
                        val badgeColor = character.resolvedColor().color
                        FilterChip(
                            selected = isSelected,
                            onClick = {
                                selectedCharacterIds = if (isSelected) {
                                    selectedCharacterIds - character.id
                                } else if (selectedCharacterIds.size < 4) {
                                    selectedCharacterIds + character.id
                                } else {
                                    selectedCharacterIds
                                }
                            },
                            label = {
                                Text("${character.name} · ${character.role}")
                            },
                            leadingIcon = if (isSelected) {
                                {
                                    Icon(
                                        imageVector = Icons.Filled.Check,
                                        contentDescription = null,
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                            } else null,
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = badgeColor.copy(alpha = 0.22f),
                                selectedLabelColor = badgeColor,
                                selectedLeadingIconColor = badgeColor
                            ),
                            modifier = Modifier.testTag("forge_cast_chip_${character.id}")
                        )
                    }
                }
            }
        }

        // Genre & Runtime
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(
                text = "2. Genre & Target Runtime",
                style = MaterialTheme.typography.titleSmall,
                color = MaterialTheme.colorScheme.primary
            )
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                DRAMATIC_GENRES.forEach { genre ->
                    FilterChip(
                        selected = selectedGenre == genre,
                        onClick = { selectedGenre = genre },
                        label = { Text(genre) },
                        modifier = Modifier.testTag("forge_genre_${genre.lowercase()}")
                    )
                }
            }

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                DURATION_OPTIONS.forEach { (sec, label) ->
                    FilterChip(
                        selected = selectedDuration == sec,
                        onClick = { selectedDuration = sec },
                        label = { Text(label) },
                        modifier = Modifier.testTag("forge_duration_$sec")
                    )
                }
            }
        }

        // Tone
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(
                text = "3. Dramatic Tone",
                style = MaterialTheme.typography.titleSmall,
                color = MaterialTheme.colorScheme.primary
            )
            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                TONE_PRESETS.forEach { tone ->
                    FilterChip(
                        selected = selectedTone == tone,
                        onClick = { selectedTone = tone },
                        label = { Text(tone) }
                    )
                }
            }
        }

        // Premise
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(
                text = "4. Central Conflict or Premise",
                style = MaterialTheme.typography.titleSmall,
                color = MaterialTheme.colorScheme.primary
            )
            OutlinedTextField(
                value = premise,
                onValueChange = { if (it.length <= 500) premise = it },
                label = { Text("What collides in this scene?") },
                placeholder = { Text("e.g. Two rivals trapped in a freight elevator before a board vote...") },
                minLines = 3,
                maxLines = 5,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("forge_premise_input")
            )

            Text(
                text = "Need a spark?",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                PREMISE_SPARKS.forEachIndexed { idx, spark ->
                    Surface(
                        onClick = { premise = spark },
                        color = MaterialTheme.colorScheme.surfaceVariant,
                        shape = RoundedCornerShape(12.dp),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                        modifier = Modifier.width(230.dp)
                    ) {
                        Text(
                            text = spark,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(10.dp),
                            maxLines = 3
                        )
                    }
                }
            }
        }

        Button(
            onClick = {
                val chosenCast = characters.filter { it.id in selectedCharacterIds }
                onForgeScript(premise, selectedGenre, selectedTone, selectedDuration, chosenCast)
            },
            enabled = !isLoading && premise.isNotBlank(),
            shape = RoundedCornerShape(14.dp),
            modifier = Modifier
                .fillMaxWidth()
                .height(54.dp)
                .testTag("forge_submit_button")
        ) {
            Icon(Icons.Filled.AutoAwesome, contentDescription = null, modifier = Modifier.size(20.dp))
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = if (isLoading) "Forging Script..." else "Forge Dramatic Script",
                style = MaterialTheme.typography.labelLarge,
                fontWeight = FontWeight.Bold
            )
        }
    }
}
