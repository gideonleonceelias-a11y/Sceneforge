package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Cinematic Noir Dark Palette (Stage Obsidian + Spotlight Amber + Dramatic Crimson)
val ObsidianBg = Color(0xFF0E0F13)
val SlateSurface = Color(0xFF161920)
val SlateSurfaceVariant = Color(0xFF20242F)
val SlateSurfaceHigh = Color(0xFF282D3B)
val HairlineSlate = Color(0xFF33394A)

val SpotlightAmber = Color(0xFFF5B841)
val SpotlightAmberDark = Color(0xFF3B2A07)
val SpotlightAmberSoft = Color(0xFFFFD98A)

val CrimsonCue = Color(0xFFE5534B)
val CrimsonCueContainer = Color(0xFF3D1716)
val CrimsonCueSoft = Color(0xFFFFB4AE)

val IvoryInk = Color(0xFFF3EFE6)
val MutedAsh = Color(0xFFB3B7C4)

// Warm Script-Paper Light Palette
val PaperCream = Color(0xFFFAF7F2)
val PaperCard = Color(0xFFF1ECE2)
val PaperSurfaceHigh = Color(0xFFE7E0D3)
val HairlinePaper = Color(0xFFD5CCB9)

val BronzePrimary = Color(0xFF9E6200)
val BronzeContainer = Color(0xFFFFE5B8)
val BronzeOnContainer = Color(0xFF331D00)

val DeepCrimson = Color(0xFFB8292F)
val DeepCrimsonContainer = Color(0xFFFFDAD8)
val DeepCrimsonOnContainer = Color(0xFF410004)

val StageInk = Color(0xFF18191E)
val PaperMutedInk = Color(0xFF5A5D68)

// Character Accent Badge Colors
val BadgeAmber = Color(0xFFF5B841)
val BadgeCrimson = Color(0xFFE5534B)
val BadgeCobalt = Color(0xFF4C9AFF)
val BadgeEmerald = Color(0xFF38B27B)
val BadgeViolet = Color(0xFFA78BFA)
