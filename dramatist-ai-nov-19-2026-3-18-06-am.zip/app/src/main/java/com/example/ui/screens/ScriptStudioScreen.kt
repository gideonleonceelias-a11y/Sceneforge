package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Save
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.PrimaryTabRow
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.R
import com.example.model.CharacterProfile
import com.example.model.DramaticScript
import com.example.model.LineType
import com.example.model.ScriptLine
import com.example.model.ScriptStatus
import com.example.ui.components.StatusPill
import com.example.ui.viewmodel.StudioViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ScriptStudioScreen(
    existingScript: DramaticScript?,
    characters: List<CharacterProfile>,
    viewModel: StudioViewModel,
    onBack: () -> Unit
) {
    val isSaving by viewModel.isSaving.collectAsStateWithLifecycle()
    val aiRewriteState by viewModel.aiRewriteState.collectAsStateWithLifecycle()

    var title by remember(existingScript?.id) {
        mutableStateOf(existingScript?.title ?: "Untitled Short Drama")
    }
    var genre by remember(existingScript?.id) { mutableStateOf(existingScript?.genre ?: "Thriller") }
    var setting by remember(existingScript?.id) {
        mutableStateOf(existingScript?.setting ?: "INT. APARTMENT HALLWAY - NIGHT")
    }
    var logline by remember(existingScript?.id) { mutableStateOf(existingScript?.logline.orEmpty()) }
    var tone by remember(existingScript?.id) { mutableStateOf(existingScript?.tone ?: "Taut & Emotional") }
    var directorNotes by remember(existingScript?.id) { mutableStateOf(existingScript?.directorNotes.orEmpty()) }
    var targetDurationSec by remember(existingScript?.id) {
        mutableLongStateOf(existingScript?.targetDurationSec ?: 60L)
    }
    var status by remember(existingScript?.id) {
        mutableStateOf(existingScript?.resolvedStatus() ?: ScriptStatus.DRAFT)
    }
    var beats by remember(existingScript?.id) { mutableStateOf(existingScript?.beats.orEmpty()) }
    var lines by remember(existingScript?.id) { mutableStateOf(existingScript?.lines.orEmpty()) }

    var activeTab by rememberSaveable { mutableIntStateOf(0) }
    var editingLineIndex by remember { mutableStateOf<Int?>(null) }
    var showAddLineDialog by remember { mutableStateOf(false) }

    DisposableEffect(Unit) {
        onDispose { viewModel.resetAiRewriteState() }
    }

    val currentDraft = DramaticScript(
        id = existingScript?.id.orEmpty(),
        userId = existingScript?.userId.orEmpty(),
        title = title.ifBlank { "Untitled Scene" },
        genre = genre,
        logline = logline,
        setting = setting,
        tone = tone,
        targetDurationSec = targetDurationSec,
        characterIds = existingScript?.characterIds.orEmpty(),
        characterNames = existingScript?.characterNames.orEmpty(),
        beats = beats,
        lines = lines,
        directorNotes = directorNotes,
        status = status.name,
        createdAt = existingScript?.createdAt,
        updatedAt = existingScript?.updatedAt
    )

    if (showAddLineDialog || editingLineIndex != null) {
        val existingLine = editingLineIndex?.let { lines.getOrNull(it) }
        ScriptLineDialog(
            initialLine = existingLine,
            suggestedSpeakers = (existingScript?.characterNames.orEmpty() + characters.map { it.name })
                .distinct()
                .filter { it.isNotBlank() },
            onConfirm = { newLine ->
                lines = if (editingLineIndex != null) {
                    lines.toMutableList().apply { set(editingLineIndex!!, newLine) }
                } else {
                    lines + newLine
                }
                showAddLineDialog = false
                editingLineIndex = null
            },
            onDelete = if (editingLineIndex != null) {
                {
                    lines = lines.toMutableList().apply { removeAt(editingLineIndex!!) }
                    editingLineIndex = null
                }
            } else null,
            onDismiss = {
                showAddLineDialog = false
                editingLineIndex = null
            }
        )
    }

    Scaffold(
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = title.ifBlank { "Untitled Scene" },
                            style = MaterialTheme.typography.titleLarge,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            text = "$genre · ${currentDraft.formattedDuration()} · ${status.label}",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                },
                navigationIcon = {
                    IconButton(
                        onClick = onBack,
                        modifier = Modifier.testTag("script_back_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = stringResource(R.string.cd_navigate_back)
                        )
                    }
                },
                actions = {
                    TextButton(
                        onClick = {
                            status = when (status) {
                                ScriptStatus.DRAFT -> ScriptStatus.REFINED
                                ScriptStatus.REFINED -> ScriptStatus.READY
                                ScriptStatus.READY -> ScriptStatus.DRAFT
                            }
                        }
                    ) {
                        Text(status.label)
                    }
                    Button(
                        onClick = {
                            viewModel.saveScript(currentDraft) {
                                if (existingScript == null) onBack()
                            }
                        },
                        enabled = !isSaving && title.isNotBlank(),
                        modifier = Modifier
                            .padding(end = 10.dp)
                            .testTag("save_script_button")
                    ) {
                        if (isSaving) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(16.dp),
                                color = MaterialTheme.colorScheme.onPrimary,
                                strokeWidth = 2.dp
                            )
                        } else {
                            Icon(Icons.Filled.Save, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Save")
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background
                )
            )
        },
        floatingActionButton = {
            if (activeTab == 0) {
                FloatingActionButton(
                    onClick = { showAddLineDialog = true },
                    containerColor = MaterialTheme.colorScheme.primary,
                    contentColor = MaterialTheme.colorScheme.onPrimary,
                    modifier = Modifier.testTag("fab_add_script_line")
                ) {
                    Icon(Icons.Filled.Add, contentDescription = stringResource(R.string.cd_add_script_line))
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .navigationBarsPadding(),
            contentAlignment = Alignment.TopCenter
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .widthIn(max = 760.dp)
            ) {
                PrimaryTabRow(
                    selectedTabIndex = activeTab,
                    containerColor = MaterialTheme.colorScheme.surface
                ) {
                    listOf("Script", "Beats", "Doctor", "Table Read").forEachIndexed { idx, label ->
                        Tab(
                            selected = activeTab == idx,
                            onClick = { activeTab = idx },
                            text = { Text(label, maxLines = 1) },
                            modifier = Modifier.testTag("script_tab_${label.lowercase().replace(" ", "_")}")
                        )
                    }
                }

                when (activeTab) {
                    0 -> ScreenplayScriptList(
                        setting = setting,
                        logline = logline,
                        lines = lines,
                        characters = characters,
                        onEditLine = { editingLineIndex = it },
                        onAddFirstLine = { showAddLineDialog = true }
                    )
                    1 -> ScriptBeatsAndNotesPanel(
                        title = title,
                        onTitleChange = { title = it },
                        genre = genre,
                        onGenreChange = { genre = it },
                        setting = setting,
                        onSettingChange = { setting = it },
                        logline = logline,
                        onLoglineChange = { logline = it },
                        tone = tone,
                        onToneChange = { tone = it },
                        directorNotes = directorNotes,
                        onDirectorNotesChange = { directorNotes = it },
                        beats = beats,
                        onAddBeat = { beats = beats + it },
                        onDeleteBeat = { idx ->
                            beats = beats.toMutableList().apply { removeAt(idx) }
                        }
                    )
                    2 -> SceneDoctorPanel(
                        aiRewriteState = aiRewriteState,
                        onRequestRewrite = { directive ->
                            val linkedCast = characters.filter {
                                it.id in currentDraft.characterIds ||
                                    currentDraft.characterNames.any { n -> n.equals(it.name, ignoreCase = true) }
                            }
                            viewModel.rewriteScriptScene(currentDraft, linkedCast, directive)
                        },
                        onApplyRewrite = { revised ->
                            title = revised.title
                            logline = revised.logline
                            setting = revised.setting
                            beats = revised.beats
                            lines = revised.lines
                            directorNotes = revised.directorNotes
                            status = ScriptStatus.REFINED
                            viewModel.saveScript(
                                currentDraft.copy(
                                    title = revised.title,
                                    logline = revised.logline,
                                    setting = revised.setting,
                                    beats = revised.beats,
                                    lines = revised.lines,
                                    directorNotes = revised.directorNotes,
                                    status = ScriptStatus.REFINED.name
                                )
                            )
                            viewModel.resetAiRewriteState()
                            activeTab = 0
                        },
                        onDismissRewrite = { viewModel.resetAiRewriteState() }
                    )
                    3 -> TableReadPanel(
                        setting = setting,
                        lines = lines
                    )
                }
            }
        }
    }
}

@Composable
private fun ScreenplayScriptList(
    setting: String,
    logline: String,
    lines: List<ScriptLine>,
    characters: List<CharacterProfile>,
    onEditLine: (Int) -> Unit,
    onAddFirstLine: () -> Unit
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 14.dp, bottom = 96.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = setting.ifBlank { "INT. SCENE LOCATION - DAY" }.uppercase(),
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.primary,
                        fontWeight = FontWeight.Bold
                    )
                    if (logline.isNotBlank()) {
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = logline,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }

        if (lines.isEmpty()) {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text(
                            text = "No script cues yet",
                            style = MaterialTheme.typography.titleMedium
                        )
                        Text(
                            text = "Add action or dialogue lines manually, or switch to the Doctor tab to generate a pass.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            textAlign = TextAlign.Center
                        )
                        Button(onClick = onAddFirstLine) {
                            Icon(Icons.Filled.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Add First Line")
                        }
                    }
                }
            }
        } else {
            itemsIndexed(lines) { index, line ->
                ScreenplayLineCard(
                    line = line,
                    characters = characters,
                    onClick = { onEditLine(index) },
                    modifier = Modifier.testTag("script_line_$index")
                )
            }
        }
    }
}

@Composable
private fun ScreenplayLineCard(
    line: ScriptLine,
    characters: List<CharacterProfile>,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val type = line.resolvedType()
    val speakerColor = remember(line.speaker, characters) {
        characters.firstOrNull { it.name.equals(line.speaker, ignoreCase = true) }
            ?.resolvedColor()?.color
    }

    Surface(
        color = when (type) {
            LineType.DIALOGUE -> MaterialTheme.colorScheme.surface
            LineType.ACTION -> MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f)
            LineType.TRANSITION -> MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.35f)
        },
        shape = RoundedCornerShape(14.dp),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.7f)),
        modifier = modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 12.dp)
        ) {
            when (type) {
                LineType.ACTION -> {
                    Text(
                        text = line.text,
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                LineType.TRANSITION -> {
                    Text(
                        text = line.text.uppercase(),
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.primary,
                        textAlign = TextAlign.End,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
                LineType.DIALOGUE -> {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(8.dp)
                                    .background(
                                        color = speakerColor ?: MaterialTheme.colorScheme.primary,
                                        shape = RoundedCornerShape(100.dp)
                                    )
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = line.speaker.ifBlank { "CHARACTER" }.uppercase(),
                                style = MaterialTheme.typography.labelLarge,
                                color = speakerColor ?: MaterialTheme.colorScheme.primary,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        if (line.emotionCue.isNotBlank()) {
                            StatusPill(
                                label = line.emotionCue,
                                containerColor = MaterialTheme.colorScheme.surfaceVariant,
                                contentColor = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    if (line.parenthetical.isNotBlank()) {
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "(${line.parenthetical})",
                            style = MaterialTheme.typography.bodySmall,
                            fontStyle = FontStyle.Italic,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(start = 16.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = line.text,
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurface,
                        modifier = Modifier.padding(start = 16.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun ScriptLineDialog(
    initialLine: ScriptLine?,
    suggestedSpeakers: List<String>,
    onConfirm: (ScriptLine) -> Unit,
    onDelete: (() -> Unit)?,
    onDismiss: () -> Unit
) {
    var lineType by remember { mutableStateOf(initialLine?.resolvedType() ?: LineType.DIALOGUE) }
    var speaker by remember { mutableStateOf(initialLine?.speaker.orEmpty()) }
    var parenthetical by remember { mutableStateOf(initialLine?.parenthetical.orEmpty()) }
    var text by remember { mutableStateOf(initialLine?.text.orEmpty()) }
    var emotionCue by remember { mutableStateOf(initialLine?.emotionCue.orEmpty()) }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = MaterialTheme.colorScheme.surface,
        title = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(if (initialLine == null) "Add Script Cue" else "Edit Script Cue")
                if (onDelete != null) {
                    IconButton(onClick = onDelete) {
                        Icon(
                            imageVector = Icons.Filled.DeleteOutline,
                            contentDescription = "Delete line",
                            tint = MaterialTheme.colorScheme.secondary
                        )
                    }
                }
            }
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    LineType.entries.forEach { type ->
                        FilterChip(
                            selected = lineType == type,
                            onClick = { lineType = type },
                            label = { Text(type.label) }
                        )
                    }
                }

                if (lineType == LineType.DIALOGUE) {
                    if (suggestedSpeakers.isNotEmpty()) {
                        Row(
                            modifier = Modifier.horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            suggestedSpeakers.forEach { candidate ->
                                FilterChip(
                                    selected = speaker.equals(candidate, ignoreCase = true),
                                    onClick = { speaker = candidate.uppercase() },
                                    label = { Text(candidate) }
                                )
                            }
                        }
                    }
                    OutlinedTextField(
                        value = speaker,
                        onValueChange = { if (it.length <= 60) speaker = it },
                        label = { Text("Speaker Name") },
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = parenthetical,
                        onValueChange = { if (it.length <= 80) parenthetical = it },
                        label = { Text("Parenthetical (Optional)") },
                        placeholder = { Text("quietly, looking away") },
                        singleLine = true
                    )
                }

                OutlinedTextField(
                    value = text,
                    onValueChange = { if (it.length <= 800) text = it },
                    label = { Text(if (lineType == LineType.DIALOGUE) "Spoken Line *" else "Action / Transition *") },
                    minLines = 3
                )

                if (lineType == LineType.DIALOGUE) {
                    OutlinedTextField(
                        value = emotionCue,
                        onValueChange = { if (it.length <= 60) emotionCue = it },
                        label = { Text("Emotion Cue (Optional)") },
                        placeholder = { Text("Tense, Vulnerable") },
                        singleLine = true
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    onConfirm(
                        ScriptLine(
                            lineType = lineType.name,
                            speaker = if (lineType == LineType.DIALOGUE) speaker.trim().uppercase() else "",
                            parenthetical = if (lineType == LineType.DIALOGUE) parenthetical.trim() else "",
                            text = text.trim(),
                            emotionCue = emotionCue.trim()
                        )
                    )
                },
                enabled = text.isNotBlank()
            ) {
                Text("Save")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}
