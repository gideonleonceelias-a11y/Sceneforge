package com.example.ui.viewmodel

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.AiStudioRepository
import com.example.data.StudioRepository
import com.example.model.CharacterInsight
import com.example.model.CharacterProfile
import com.example.model.DramaticScript
import com.google.firebase.firestore.FirebaseFirestoreException
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

sealed interface UiState<out T> {
    data object Loading : UiState<Nothing>
    data class Success<T>(val data: T) : UiState<T>
    data class Error(val message: String) : UiState<Nothing>
}

sealed interface AiState<out T> {
    data object Idle : AiState<Nothing>
    data class Loading(val progressDetail: String? = null) : AiState<Nothing>
    data class Success<T>(val data: T) : AiState<T>
    data class Error(val message: String) : AiState<Nothing>
}

class StudioViewModel(
    private val repository: StudioRepository,
    private val aiRepository: AiStudioRepository,
    private val currentUserId: String
) : ViewModel() {

    val charactersState: StateFlow<UiState<List<CharacterProfile>>> =
        repository.observeCharacters(currentUserId)
            .map<List<CharacterProfile>, UiState<List<CharacterProfile>>> { UiState.Success(it) }
            .catch { error ->
                val firestoreError = generateSequence(error) { it.cause }
                    .filterIsInstance<FirebaseFirestoreException>()
                    .firstOrNull()
                if (firestoreError == null && error is CancellationException) throw error
                val rootError = firestoreError ?: error
                Log.w(TAG, "Error observing characters", rootError)
                emit(UiState.Error(rootError.message ?: "Failed to load characters."))
            }
            .stateIn(
                scope = viewModelScope,
                started = SharingStarted.WhileSubscribed(STOP_TIMEOUT_MILLIS),
                initialValue = UiState.Loading
            )

    val scriptsState: StateFlow<UiState<List<DramaticScript>>> =
        repository.observeScripts(currentUserId)
            .map<List<DramaticScript>, UiState<List<DramaticScript>>> { UiState.Success(it) }
            .catch { error ->
                val firestoreError = generateSequence(error) { it.cause }
                    .filterIsInstance<FirebaseFirestoreException>()
                    .firstOrNull()
                if (firestoreError == null && error is CancellationException) throw error
                val rootError = firestoreError ?: error
                Log.w(TAG, "Error observing scripts", rootError)
                emit(UiState.Error(rootError.message ?: "Failed to load scripts."))
            }
            .stateIn(
                scope = viewModelScope,
                started = SharingStarted.WhileSubscribed(STOP_TIMEOUT_MILLIS),
                initialValue = UiState.Loading
            )

    private val _aiCharacterState = MutableStateFlow<AiState<CharacterProfile>>(AiState.Idle)
    val aiCharacterState: StateFlow<AiState<CharacterProfile>> = _aiCharacterState.asStateFlow()

    private val _aiInsightState = MutableStateFlow<AiState<CharacterInsight>>(AiState.Idle)
    val aiInsightState: StateFlow<AiState<CharacterInsight>> = _aiInsightState.asStateFlow()

    private val _aiForgeState = MutableStateFlow<AiState<String>>(AiState.Idle)
    val aiForgeState: StateFlow<AiState<String>> = _aiForgeState.asStateFlow()

    private val _aiRewriteState = MutableStateFlow<AiState<DramaticScript>>(AiState.Idle)
    val aiRewriteState: StateFlow<AiState<DramaticScript>> = _aiRewriteState.asStateFlow()

    private val _feedbackMessage = MutableStateFlow<String?>(null)
    val feedbackMessage: StateFlow<String?> = _feedbackMessage.asStateFlow()

    private val _isSaving = MutableStateFlow(false)
    val isSaving: StateFlow<Boolean> = _isSaving.asStateFlow()

    fun clearFeedback() {
        _feedbackMessage.value = null
    }

    fun resetAiCharacterState() {
        _aiCharacterState.value = AiState.Idle
    }

    fun resetAiInsightState() {
        _aiInsightState.value = AiState.Idle
    }

    fun resetAiForgeState() {
        _aiForgeState.value = AiState.Idle
    }

    fun resetAiRewriteState() {
        _aiRewriteState.value = AiState.Idle
    }

    fun saveCharacter(character: CharacterProfile, onSaved: (String) -> Unit = {}) {
        viewModelScope.launch {
            _isSaving.value = true
            val result = repository.saveCharacter(currentUserId, character)
            _isSaving.value = false
            result.onSuccess { savedId ->
                _feedbackMessage.value = "Character saved to cast."
                onSaved(savedId)
            }.onFailure { error ->
                _feedbackMessage.value = error.localizedMessage ?: "Unable to save character."
            }
        }
    }

    fun deleteCharacter(characterId: String, onDeleted: () -> Unit = {}) {
        viewModelScope.launch {
            val result = repository.deleteCharacter(currentUserId, characterId)
            result.onSuccess {
                _feedbackMessage.value = "Character removed from cast."
                onDeleted()
            }.onFailure { error ->
                _feedbackMessage.value = error.localizedMessage ?: "Unable to delete character."
            }
        }
    }

    fun saveScript(script: DramaticScript, onSaved: (String) -> Unit = {}) {
        viewModelScope.launch {
            _isSaving.value = true
            val result = repository.saveScript(currentUserId, script)
            _isSaving.value = false
            result.onSuccess { savedId ->
                _feedbackMessage.value = "Script saved to studio."
                onSaved(savedId)
            }.onFailure { error ->
                _feedbackMessage.value = error.localizedMessage ?: "Unable to save script."
            }
        }
    }

    fun deleteScript(scriptId: String, onDeleted: () -> Unit = {}) {
        viewModelScope.launch {
            val result = repository.deleteScript(currentUserId, scriptId)
            result.onSuccess {
                _feedbackMessage.value = "Script deleted."
                onDeleted()
            }.onFailure { error ->
                _feedbackMessage.value = error.localizedMessage ?: "Unable to delete script."
            }
        }
    }

    fun generateCharacterDraft(concept: String, preferredRole: String, genre: String) {
        if (concept.isBlank()) {
            _aiCharacterState.value = AiState.Error("Describe a brief character concept first.")
            return
        }
        viewModelScope.launch {
            _aiCharacterState.value = AiState.Loading("Sculpting character dossier...")
            val result = aiRepository.generateCharacterProfile(
                concept = concept,
                preferredRole = preferredRole,
                genre = genre,
                onProgress = { chars ->
                    if (chars > 0) {
                        _aiCharacterState.value = AiState.Loading("Sculpting character... ($chars chars)")
                    } else {
                        _aiCharacterState.value = AiState.Loading("Switching to fast studio model...")
                    }
                }
            )
            _aiCharacterState.value = result.fold(
                onSuccess = { AiState.Success(it) },
                onFailure = { AiState.Error(it.localizedMessage ?: "Character generation failed.") }
            )
        }
    }

    fun analyzeCharacterConflict(character: CharacterProfile) {
        if (character.name.isBlank()) {
            _aiInsightState.value = AiState.Error("Give your character a name before analyzing conflict.")
            return
        }
        viewModelScope.launch {
            _aiInsightState.value = AiState.Loading("Analyzing dramatic tension...")
            val result = aiRepository.analyzeCharacterConflict(
                character = character,
                onProgress = { chars ->
                    if (chars > 0) {
                        _aiInsightState.value = AiState.Loading("Analyzing subtext... ($chars chars)")
                    } else {
                        _aiInsightState.value = AiState.Loading("Switching to fast studio model...")
                    }
                }
            )
            _aiInsightState.value = result.fold(
                onSuccess = { AiState.Success(it) },
                onFailure = { AiState.Error(it.localizedMessage ?: "Conflict analysis failed.") }
            )
        }
    }

    fun forgeAndSaveScript(
        premise: String,
        genre: String,
        tone: String,
        targetDurationSec: Int,
        cast: List<CharacterProfile>,
        onScriptCreated: (String) -> Unit
    ) {
        if (premise.isBlank()) {
            _aiForgeState.value = AiState.Error("Enter a dramatic premise or scene conflict first.")
            return
        }
        viewModelScope.launch {
            _aiForgeState.value = AiState.Loading("Sculpting story beats and dialogue...")
            val aiResult = aiRepository.forgeDramaticScript(
                premise = premise,
                genre = genre,
                tone = tone,
                targetDurationSec = targetDurationSec,
                cast = cast,
                onProgress = { chars ->
                    if (chars > 0) {
                        _aiForgeState.value = AiState.Loading("Drafting screenplay cues... ($chars chars)")
                    } else {
                        _aiForgeState.value = AiState.Loading("Retrying with fast studio model...")
                    }
                }
            )
            aiResult.fold(
                onSuccess = { generatedScript ->
                    val saveResult = repository.saveScript(currentUserId, generatedScript)
                    saveResult.fold(
                        onSuccess = { scriptId ->
                            _aiForgeState.value = AiState.Success(scriptId)
                            _feedbackMessage.value = "Script forged and saved!"
                            onScriptCreated(scriptId)
                        },
                        onFailure = { err ->
                            _aiForgeState.value = AiState.Error(
                                err.localizedMessage ?: "Script was forged, but saving failed."
                            )
                        }
                    )
                },
                onFailure = { err ->
                    _aiForgeState.value = AiState.Error(
                        err.localizedMessage ?: "Unable to forge script."
                    )
                }
            )
        }
    }

    fun rewriteScriptScene(
        script: DramaticScript,
        cast: List<CharacterProfile>,
        directive: String
    ) {
        if (directive.isBlank()) {
            _aiRewriteState.value = AiState.Error("Enter a rewrite note or pick a Scene Doctor preset.")
            return
        }
        viewModelScope.launch {
            _aiRewriteState.value = AiState.Loading("Elevating tension and subtext...")
            val result = aiRepository.rewriteScriptScene(
                script = script,
                cast = cast,
                directive = directive,
                onProgress = { chars ->
                    if (chars > 0) {
                        _aiRewriteState.value = AiState.Loading("Rewriting scene... ($chars chars)")
                    } else {
                        _aiRewriteState.value = AiState.Loading("Retrying with fast studio model...")
                    }
                }
            )
            _aiRewriteState.value = result.fold(
                onSuccess = { AiState.Success(it) },
                onFailure = { AiState.Error(it.localizedMessage ?: "Scene rewrite failed.") }
            )
        }
    }

    private companion object {
        const val TAG = "StudioViewModel"
        const val STOP_TIMEOUT_MILLIS = 5000L
    }
}
