package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.credentials.CredentialManager
import androidx.lifecycle.ViewModelProvider.AndroidViewModelFactory.Companion.APPLICATION_KEY
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.data.AiStudioRepository
import com.example.data.StudioRepository
import com.example.firebase.authStateFlow
import com.example.firebase.configureAppCheck
import com.example.firebase.signOut
import com.example.ui.screens.AuthScreen
import com.example.ui.screens.CharacterStudioScreen
import com.example.ui.screens.ScriptStudioScreen
import com.example.ui.screens.StudioHomeScreen
import com.example.ui.theme.SceneForgeTheme
import com.example.ui.viewmodel.StudioViewModel
import com.example.ui.viewmodel.UiState
import com.google.firebase.Firebase
import com.google.firebase.auth.auth
import com.google.firebase.firestore.FirebaseFirestore

private const val ROUTE_HOME = "studio_home"
private const val ROUTE_SCRIPT_NEW = "script_detail/new"
private const val ROUTE_SCRIPT_DETAIL = "script_detail/{scriptId}"
private const val ROUTE_CHARACTER_NEW = "character_detail/new"
private const val ROUTE_CHARACTER_DETAIL = "character_detail/{characterId}"

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // STEP 1: Configure App Check with launch intent before rendering UI or creating ViewModels
        configureAppCheck(this, intent)

        enableEdgeToEdge()
        setContent {
            SceneForgeTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    AppNavigation()
                }
            }
        }
    }
}

@Composable
fun AppNavigation() {
    val auth = remember { Firebase.auth }
    val currentUser by auth.authStateFlow().collectAsStateWithLifecycle(initialValue = auth.currentUser)
    val user = currentUser

    if (user == null) {
        AuthScreen(onAuthSuccess = {})
    } else {
        key(user.uid) {
            AuthenticatedStudioNavHost(currentUserId = user.uid)
        }
    }
}

@Composable
private fun AuthenticatedStudioNavHost(currentUserId: String) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val credentialManager = remember(context) { CredentialManager.create(context) }
    val navController = rememberNavController()

    val viewModel: StudioViewModel = viewModel(
        key = currentUserId,
        factory = viewModelFactory {
            initializer {
                val app = checkNotNull(this[APPLICATION_KEY]) {
                    "APPLICATION_KEY missing from CreationExtras"
                }
                val databaseId = app.getString(R.string.firestore_database_id)
                val db = FirebaseFirestore.getInstance(databaseId)
                StudioViewModel(
                    repository = StudioRepository(db),
                    aiRepository = AiStudioRepository(),
                    currentUserId = currentUserId
                )
            }
        }
    )

    val charactersState by viewModel.charactersState.collectAsStateWithLifecycle()
    val scriptsState by viewModel.scriptsState.collectAsStateWithLifecycle()

    val charactersList = (charactersState as? UiState.Success)?.data.orEmpty()
    val scriptsList = (scriptsState as? UiState.Success)?.data.orEmpty()

    NavHost(
        navController = navController,
        startDestination = ROUTE_HOME
    ) {
        composable(ROUTE_HOME) {
            StudioHomeScreen(
                viewModel = viewModel,
                onOpenScript = { scriptId ->
                    navController.navigate("script_detail/$scriptId")
                },
                onCreateBlankScript = {
                    navController.navigate(ROUTE_SCRIPT_NEW)
                },
                onOpenCharacter = { charId ->
                    navController.navigate("character_detail/$charId")
                },
                onCreateCharacter = {
                    navController.navigate(ROUTE_CHARACTER_NEW)
                },
                onSignOut = {
                    signOut(credentialManager, scope)
                }
            )
        }

        composable(ROUTE_SCRIPT_NEW) {
            ScriptStudioScreen(
                existingScript = null,
                characters = charactersList,
                viewModel = viewModel,
                onBack = { navController.popBackStack() }
            )
        }

        composable(
            route = ROUTE_SCRIPT_DETAIL,
            arguments = listOf(navArgument("scriptId") { type = NavType.StringType })
        ) { backStackEntry ->
            val scriptId = backStackEntry.arguments?.getString("scriptId").orEmpty()
            val script = scriptsList.firstOrNull { it.id == scriptId }
            if (script == null && scriptsState is UiState.Loading) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator(color = MaterialTheme.colorScheme.primary)
                }
            } else {
                ScriptStudioScreen(
                    existingScript = script,
                    characters = charactersList,
                    viewModel = viewModel,
                    onBack = { navController.popBackStack() }
                )
            }
        }

        composable(ROUTE_CHARACTER_NEW) {
            CharacterStudioScreen(
                existingCharacter = null,
                viewModel = viewModel,
                onBack = { navController.popBackStack() }
            )
        }

        composable(
            route = ROUTE_CHARACTER_DETAIL,
            arguments = listOf(navArgument("characterId") { type = NavType.StringType })
        ) { backStackEntry ->
            val charId = backStackEntry.arguments?.getString("characterId").orEmpty()
            val character = charactersList.firstOrNull { it.id == charId }
            if (character == null && charactersState is UiState.Loading) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator(color = MaterialTheme.colorScheme.primary)
                }
            } else {
                CharacterStudioScreen(
                    existingCharacter = character,
                    viewModel = viewModel,
                    onBack = { navController.popBackStack() }
                )
            }
        }
    }
}
