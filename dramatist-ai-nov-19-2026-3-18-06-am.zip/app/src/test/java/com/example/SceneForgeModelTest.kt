package com.example

import com.example.model.AccentColorKey
import com.example.model.BeatType
import com.example.model.CharacterProfile
import com.example.model.DramaticScript
import com.example.model.LineType
import com.example.model.ScriptBeat
import com.example.model.ScriptLine
import com.example.model.ScriptStatus
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class SceneForgeModelTest {

    @Test
    fun `character create map matches firestore rules keyset and excludes id`() {
        val character = CharacterProfile(
            id = "char_123",
            name = "Elena Vance",
            role = "Protagonist",
            archetype = "Whistleblower",
            coreDesire = "Protect her source",
            fatalFlaw = "Refuses help",
            accentColorKey = AccentColorKey.CRIMSON.name
        )

        val createMap = character.toCreateMap("user_abc")
        assertFalse(createMap.containsKey("id"))
        assertEquals("user_abc", createMap["userId"])
        assertEquals(
            setOf(
                "userId", "name", "role", "archetype", "ageOrLook",
                "coreDesire", "fatalFlaw", "backstory", "voiceStyle",
                "accentColorKey", "createdAt", "updatedAt"
            ),
            createMap.keys
        )

        val updateMap = character.toUpdateMap()
        assertFalse(updateMap.containsKey("userId"))
        assertFalse(updateMap.containsKey("createdAt"))
        assertTrue(updateMap.containsKey("updatedAt"))
    }

    @Test
    fun `script create map matches firestore rules bounds and excludes id`() {
        val script = DramaticScript(
            id = "script_99",
            title = "Last Train Car",
            genre = "Thriller",
            targetDurationSec = 90L,
            beats = listOf(ScriptBeat("Hook", BeatType.HOOK.name, "ECU", "Doors lock")),
            lines = listOf(ScriptLine(LineType.DIALOGUE.name, "ELENA", "tense", "Leave now.", "Urgent")),
            status = ScriptStatus.REFINED.name
        )

        val createMap = script.toCreateMap("user_abc")
        assertFalse(createMap.containsKey("id"))
        assertEquals(90L, createMap["targetDurationSec"])
        assertEquals(
            setOf(
                "userId", "title", "genre", "logline", "setting", "tone",
                "targetDurationSec", "characterIds", "characterNames",
                "beats", "lines", "directorNotes", "status", "createdAt", "updatedAt"
            ),
            createMap.keys
        )
    }

    @Test
    fun `enum fallbacks handle unknown values safely`() {
        assertEquals(AccentColorKey.AMBER, AccentColorKey.fromRaw("UNKNOWN"))
        assertEquals(BeatType.ESCALATION, BeatType.fromRaw("UNKNOWN"))
        assertEquals(LineType.ACTION, LineType.fromRaw("UNKNOWN"))
        assertEquals(ScriptStatus.DRAFT, ScriptStatus.fromRaw("UNKNOWN"))
    }
}
